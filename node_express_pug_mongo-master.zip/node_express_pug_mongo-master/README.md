# CRUD application  

## Overview
A standard CRUD application that manages articles using Node.js, Express.js.

The goal is to experiment Pug, MongoDB (with Mongoose), Passport, express-validator and express-messages.

## Usage
Clone the project and run:
1. `npm install`
2. `npm start`
